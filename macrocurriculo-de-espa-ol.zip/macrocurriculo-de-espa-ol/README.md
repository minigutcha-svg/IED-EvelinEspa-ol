# Macrocurriculo de Español

A Pen created on CodePen.

Original URL: [https://codepen.io/Milton-Gutierrez-the-flexboxer/pen/KwVyReM](https://codepen.io/Milton-Gutierrez-the-flexboxer/pen/KwVyReM).

